Yii2-rbac documentation
=======================

Getting Started
---------------

- [Installation](installation.md)

Guides
------

- [Using custom auth manager](using-custom-auth-manager.md)