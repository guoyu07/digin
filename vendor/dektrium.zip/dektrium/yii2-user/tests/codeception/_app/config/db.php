<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=dektrium_test',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];