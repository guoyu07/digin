<?php

new yii\web\Application(require(dirname(__DIR__) . '/_config/unit.php'));